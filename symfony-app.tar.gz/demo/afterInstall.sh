mkdir test
#php -S localhost:8000 -t /home/admin/symfony-app/public/
